CREATE TRIGGER ICustomer
ON   [dbo].[Count_Req_ExBody]
AFTER INSERT--, UPDATE, DELETE   
AS  


 INSERT INTO dbo.DIC_CUSTOMER (NAME, FNAME,SURNAME, qUNI)
(
	Select  i.[ExBody_Name],i.[ExBody_FName],i.[ExBody_Surname], i.qUNI  from inserted i
	EXCEPT
	Select NAME, FNAME, SURNAME, qUNI From dbo.DIC_CUSTOMER (NOLOCK)
)

go

