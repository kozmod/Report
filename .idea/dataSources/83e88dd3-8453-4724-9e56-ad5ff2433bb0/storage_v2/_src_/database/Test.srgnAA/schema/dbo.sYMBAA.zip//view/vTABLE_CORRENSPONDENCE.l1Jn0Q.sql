
CREATE VIEW [dbo].[vTABLE_CORRENSPONDENCE]
as
SELECT DISTINCT
	N.Name
	,FRK.Name_cor
FROM [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM] FRK_ACT (nolock)
INNER JOIN [dbo].[FRK_ACCOUNT_FRK] FRK (nolock)
	on FRK.[ID_IDEAL_CORR] = FRK_ACT.[ID_IDEAL_CORR]
	and FRK.dell = 0
INNER JOIN [dbo].[DIC_Count_Name] N (nolock)
	on N.ID = FRK_ACT.ID_COUNT
	and N.dell = 0
WHERE FRK_ACT.dell = 0
union all
SELECT
	'-1'
	,Name_Cor
FROM dbo.ACCOUNT A (nolock)
Where 
	A.[ID_IDEAL_CORR] = -1 
	AND A.DELL = 0
GO

