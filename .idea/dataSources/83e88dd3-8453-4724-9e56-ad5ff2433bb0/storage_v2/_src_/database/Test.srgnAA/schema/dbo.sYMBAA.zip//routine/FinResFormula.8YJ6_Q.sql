

CREATE procedure [dbo].[FinResFormula]
as

	Select
		S.*
		,SE.[Type]
		,SE.[Value]
		,Row_number() over(partition by S.[Contractor],S.[SiteNumber] order by SE.[id]) as RN
	into #Site
	From  [dbo].[Site] S
	left join [dbo].[SiteExpenses] SE
		on SE.[Contractor] = S.[Contractor]
		and SE.[SiteNumber] = S.[SiteNumber]
	where S.dell = 0
		and SE.dell = 0



	;with
		CTE as (Select 
					S.[RN]
					,case	when S.[Type] = 0 then S.[SaleHouse] - S.[SaleHouse] * S.Value / 100 
							when S.[Type] = 1 then S.[SaleHouse] - S.Value
					else  S.[SaleHouse]
					end	as [Res]
					,S.[Contractor]
					,S.[SiteNumber]
					,S.[id]
				From  #Site S
				Where S.RN = 1
				union all
				Select
					S.[RN]
					,case	when S.[Type] = 0 then C.[Res] - C.[Res] * S.Value / 100 
							when S.[Type] = 1 then C.[Res] - S.Value
					else  C.[Res]
					end	as [Res]
					,S.[Contractor]
					,S.[SiteNumber]
					,S.[id]
				From CTE C 
				join #Site S
					on S.[Contractor]	= C.[Contractor]
					and S.[SiteNumber]	= C.[SiteNumber]
					and S.RN			= C.RN+1
			)
			
				Select 
					CTE.[Contractor]
					,CTE.[SiteNumber]
					,sum(CTE.Res) as [Delta]
				into #Site_all
				From CTE
				Group by 
					CTE.[Contractor]
					,CTE.[SiteNumber]
				

			--)Res



/*

			Select  
				S.Contractor
				,S.SiteNumber
				,case	when SE.[Type] = 0 then S.[SaleHouse] * SE.Value / 100 
						when SE.[Type] = 1 then S.[SaleHouse] - SE.Value
				else  S.[SaleHouse]
				end	as [Res]

			From [dbo].[Site] S
			left join [dbo].[SiteExpenses] SE
				on SE.Contractor = S.Contractor
				and SE.SiteNumber = S.SiteNumber
*/

			Select
				R.[Contractor]
				,R.[SiteNumber]	
				,max(R.[SaleHouse])	as [SaleHouse]
				,round(max(R.[SaleHouse]) - max(isnull(S.[Delta],0)) - sum(case 
					when d.[count_s] is null then 
														isnull(a.[ACount],0) / (isnull(dFTft.count_s,0) + isnull(dFT.count_s,0))
					when d.[count_s] is not null and SJP.id is not null then 
														isnull(aFT.[ACount],0) / (isnull(dFTft.count_s,0) + isnull(dFT.count_s,0))
				else 0
				end),2) as [Res]
				,max(NContract		)	as [NContract]
				,max(DateContract	)	as [DateContract]
				,max(FinishBuilding	)	as [FinishBuilding]
				,max(SmetCost		)	as [SmetCost]
				,max(CostHouse		)	as [CostHouse]
				--, a.[ACount]
			From Dbo.[Site] R
			left join [dbo].[SiteJobPeriod] SJP
				on SJP.[Contractor] = R.[Contractor]
				and SJP.[SiteNumber] = R.[SiteNumber] 
				and R.[DateContract] <= SJP.[DateFrom] 
				and R.[FinishBuilding] >= SJP.[DateTo]
				and SJP.dell = 0
			outer apply(Select top 1 1 as [count_s] From [dbo].[SiteJobPeriod] SJP Where SJP.[Contractor] = R.[Contractor] and  SJP.[SiteNumber] = R.[SiteNumber] and SJP.dell = 0)d
			outer apply(Select sum(A.deb) as [ACount] From [dbo].[Account] A where A.[Date] between R.[DateContract] and  R.[FinishBuilding] and dell = 0)a
			outer apply(Select sum(A.deb) as [ACount] From [dbo].[Account] A where A.[Date] between SJP.[DateFrom] and  SJP.[DateTo] and dell = 0)aFT
			outer apply(
						Select top 1
							count(DISTINCT SJP1.SiteNumber) as [count_s] 
						From [dbo].[SiteJobPeriod] SJP1 
						Where 
							(isnull(SJP.[DateFrom], R.DateContract) <= SJP1.[DateTo]
							and isnull(SJP.[DateTo], R.FinishBuilding) >= SJP1.[DateFrom])
							and SJP1.dell = 0
						)dFTft
			outer apply(
						Select top 1
							count(DISTINCT S1.id) as [count_s] 
						From [dbo].[Site] S1 
						Where 
							S1.dell = 0
							and
								(
									isnull(SJP.[DateFrom],R.DateContract) <= S1.FinishBuilding
								and	isnull(SJP.[DateTO],R.FinishBuilding) >= S1.DateContract
								)
							and not exists (select 
											1 
										from [dbo].[SiteJobPeriod] SJP2 
										where 
											SJP2.[Contractor] = S1.[Contractor] 
											and SJP2.[SiteNumber] = S1.[SiteNumber] 
											and SJP2.dell = 0
										)

							
						)dFT
		left join #Site_all S
			on		R.[Contractor] = S.[Contractor]
					and R.[SiteNumber] = S.[SiteNumber]
		where R.dell = 0 
		group by 		
				R.[Contractor]
				,R.[SiteNumber]	
						
						
			--			Select top 1 
			--				count(DISTINCT isnull(SJP.SiteNumber, S.id)) as [count_s] 
			--			From [dbo].[SiteJobPeriod] SJP 
			--			left join [dbo].[SiteJobPeriod] SJP1
			--				on (SJP.[DateFrom] <= SJP1.[DateFrom] 
			--				or SJP.[DateTO] >= SJP1.[DateTo])
			--				and SJP1.dell = 0

			--			left join dbo.[Site] S
			--				on (SJP.[DateFrom] <= S.DateContract 
			--				or SJP.[DateTO] >= S.FinishBilding)
			--				and S.dell = 0
			--			Where 
			--				SJP.[Contractor] = R.[Contractor] 
			--				and  SJP.[SiteNumber] = R.[SiteNumber] 
			--				and SJP.dell = 0 
			--				and R.[DateContract] <= SJP.[DateFrom] 
			--				and R.[FinishBilding] >= SJP.[DateTo]
			--				)dFT
			--outer apply(Select top 1 From dbo.[Site] where 



			--outer apply(Select )
			----dbo.SiteJobPeriod

GO
