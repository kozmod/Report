CREATE PROCEDURE [dbo].[getCurrentElement]
@ColumnName varchar(100), @SiteNumber varchar(50),@Contractor varchar(100)
AS
BEGIN

SET NOCOUNT ON;

DECLARE @SQL nvarchar(1000);

SET @SQL = N'
				Select 
					'+@ColumnName+' 
				From dbo.[Site] S
				Where [SiteNumber] = '''  +@SiteNumber+'''
				and [Contractor] like '''+@Contractor+''''
				
EXEC (@SQL)
END
GO
