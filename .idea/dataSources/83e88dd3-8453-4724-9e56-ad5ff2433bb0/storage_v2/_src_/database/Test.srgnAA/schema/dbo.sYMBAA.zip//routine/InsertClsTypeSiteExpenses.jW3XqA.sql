create procedure [dbo].[InsertClsTypeSiteExpenses]
	@name	varchar(300) = null
as
begin

insert into [dbo].[clsTypeSiteExpenses]([idType],[name])
Select 
	TE.idType
	,TE.name
from dbo.clsTypeSiteExpenses TE 
where 
	TE.[dell] = 1 
	and TE.name = rtrim(ltrim(@name))

IF @@ROWCOUNT = 0
	insert into [dbo].[clsTypeSiteExpenses]([idType],[name]) 
	Select
		top 1
		TSE.idType
		,@name
	From [dbo].[clsTypeSiteExpenses] TSE
	Order by 
		TSE.idType desc
end
GO
