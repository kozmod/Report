
CREATE TRIGGER qUNI
ON  [dbo].[Count_Req_ExBody] 
FOR INSERT--, UPDATE, DELETE   
AS  


 INSERT INTO [dbo].[Count_Req_ExBody] (
								[id_Count]				
								,[id_ExBody]				
								,[ExBody]				
								,[ExBody_Surname]		
								,[ExBody_Name]			
								,[ExBody_FName]			
								,[Bookkeeper_Surname]	
								,[Bookkeeper_Name]		
								,[Bookkeeper_FName]		
								,[ID_Series]				
								,[ID_Number]				
								,[ID_Date]				
								,[ID_Text]				
								,[ID_Code]						
								,[dell]					
								,[DateCreate]			
								,[ActionBasis]
								,qUNI			
								)
SELECT
	[id_Count]				
								,[id_ExBody]				
								,[ExBody]				
								,[ExBody_Surname]		
								,[ExBody_Name]			
								,[ExBody_FName]			
								,[Bookkeeper_Surname]	
								,[Bookkeeper_Name]		
								,[Bookkeeper_FName]		
								,[ID_Series]				
								,[ID_Number]				
								,[ID_Date]				
								,[ID_Text]				
								,[ID_Code]						
								,[dell]					
								,[DateCreate]			
								,[ActionBasis]
								,coalesce(C.qUNI,I.qUNI, newID())			
	FROM INSERTED I
	LEFT JOIN dbo.DIC_CUSTOMER C(NOLOCK)
		on c.NAME = i.[ExBody_Name]
		and c.FNAME = i.[ExBody_FName]
		and c.SURNAME = i.[ExBody_Surname]
	WHERE 
		EXISTS(
			Select  i.[ExBody_Name],i.[ExBody_FName],i.[ExBody_Surname] 
			EXCEPT
			Select C.NAME, C.FNAME, C.SURNAME 
		)

go

