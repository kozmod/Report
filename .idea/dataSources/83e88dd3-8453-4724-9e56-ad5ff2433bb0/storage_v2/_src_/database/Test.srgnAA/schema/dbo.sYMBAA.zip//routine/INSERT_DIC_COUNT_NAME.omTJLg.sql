CREATE PROCEDURE [dbo].[INSERT_DIC_COUNT_NAME]   
--declare
	@Name		varchar(100) = null  
	,@New_name	varchar(100) = null 
	--	@Name		varchar(100) = 'ТрестСтрой'  
	--,@New_name	varchar(100) = 'Грэм
AS 
/*  
exec dbo.INSERT_DIC_COUNT_NAME  
@name = 'ДДД' 
*/ 
BEGIN    

	declare   
		@ID_COUNT	int = null   
		,@ID		int = null  
		
	declare    
		@OutputTbl TABLE (ID INT)   
		
	--set @Name = case when @Name = '-1' or @Name is null then @New_Name else @Name end   
	
	BEGIN TRAN  
	
		--проверяем новое имя   
		--ищем элемент  
		
		SELECT 
			@ID_COUNT = ID_COUNT
			, @ID = ID 
		FROM [dbo].[DIC_Count_NAME] (NOLOCK) 
		WHERE 
			NAME = @NAME 
			and dell = 0   

			--SELECT @ID, @ID_COUNT
	
		--удаляем его  
		
		IF not exists(SELECT 1 FROM [dbo].[DIC_COUNT_NAME] (nolock) WHERE NAME = @New_Name and dell = 0) 
			UPDATE [dbo].[DIC_Count_NAME]    
				set dell = 1  
			OUTPUT DELETED.ID into @OutputTbl
			WHERE 
				ID_COUNT = @ID_COUNT    
		ELSE
			UPDATE [dbo].[DIC_Count_NAME] 
				set  dell = 1 
			WHERE 
				ID_COUNT = @ID_COUNT  
				
				
		
		
		IF (@Name = '-1' or @Name is null or @ID is null) --новый элемент или не существующий старый
			Begin  
				--IF (@ID IS NULL) 
				--	begin
				--	rollback;
				--	return; --если старый не существует, то ошибка
				--	end
				--вставляем новый
				begin try
				INSERT INTO  [dbo].[DIC_Count_NAME]([id_COUNT],[Name])    
				OUTPUT INSERTED.ID
				SELECT top 1     
					max(ID_COUNT)     
					,@New_Name    
				FROM  [dbo].[DIC_Count_NAME](nolock) N
				WHERE 1=1
					and NAME = @New_name
					and dell = 1 
					and not exists (Select Top 1 1 From  [dbo].[DIC_Count_NAME] N1 Where dell = 0 and N.id_Count = N1.ID_COUNT)

				  end try
				  begin catch
				  	
					INSERT INTO  [dbo].[DIC_Count_NAME]([id_COUNT],[Name]) 
					OUTPUT INSERTED.ID
					SELECT top 1     
						isnull(max(ID_COUNT)+1,-1)     
						,@New_Name    
					FROM  [dbo].[DIC_Count_NAME](nolock)
					WHERE 1=1
						and dell = 0 
				  end catch

				
				IF (Select count(1) FROM [dbo].[DIC_Count_NAME] (nolock) ) = 0     
					INSERT INTO  [dbo].[DIC_Count_NAME]([id_COUNT],[Name]) OUTPUT INSERTED.ID  VALUES (1,@New_Name)   
					
			End    
			
		ELSE  
			Begin   
			
			--SELECT @ID_COUNT =  isnull(max(ID_COUNT),-1) FROM [dbo].[DIC_Count_NAME](nolock)    
			
			--вставляем его в таблицу      
			
				if exists(SELECT  ID_COUNT FROM [dbo].[DIC_COUNT_NAME] CN (nolock) inner join @OutputTbl T on T.id = CN.id)  
					begin
						--чистим буферную табличку
						delete from @OutputTbl
						 --старое на новое 
						INSERT INTO [dbo].[DIC_Count_NAME]([id_COUNT],[Name])
							OUTPUT INSERTED.id INTO @OutputTbl  
						VALUES (@ID_COUNT,@New_Name) 
					end
				else    
						INSERT INTO @OutputTbl
						select 
							ID
						FROM [dbo].[DIC_COUNT_NAME] (nolock) 
						WHERE 
							1=1
							and NAME = @New_Name 
							and dell = 0        
							
							
						
					
					
				IF object_id('tempdb..#FRK_ACCOUNT_COUNT_TYPE_FORM_temp') is not null    
					drop table #FRK_ACCOUNT_COUNT_TYPE_FORM_temp    
					
				CREATE TABLE #FRK_ACCOUNT_COUNT_TYPE_FORM_temp (               
																[ID_IDEAL_CORR]	int
																,ID_COUNT	int
																,ID_FORM	int
																,ID_TYPE	int               
																)    
																
				--удаляем его из таблицы зависимостей   
				UPDATE [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM]    
					set dell = 1   
				OUTPUT     
					DELETED.[ID_IDEAL_CORR]    
					,DELETED.ID_COUNT    
					,DELETED.ID_FORM    
					,DELETED.ID_TYPE   
				into #FRK_ACCOUNT_COUNT_TYPE_FORM_temp   
				WHERE ID_COUNT = @ID       
				
				INSERT INTO dbo.FRK_ACCOUNT_COUNT_TYPE_FORM ([ID_IDEAL_CORR], ID_COUNT, ID_FORM, ID_TYPE)   
				SELECT     
					FRK.[ID_IDEAL_CORR]    
					,O.ID    
					,FRK.ID_FORM    
					,FRK.ID_TYPE   
				FROM #FRK_ACCOUNT_COUNT_TYPE_FORM_temp FRK   
				cross join @OutputTbl O  
			End  
				
	commit tran;  
end
GO

