

CREATE VIEW [dbo].[vCOMPANY_IDEAL_COR]
AS
SELECT DISTINCT
	 F.Name				as Name_Form
	 ,N.Name			as Name_Count
	 ,T.Name			as Name_Type
	 ,ACTF.ID_FORM
	 ,ACTF.ID_COUNT
	 ,ACTF.ID_TYPE
	 ,N.id_Count		as ID_Count_Const
	 ,T.id_Type			as [ID_Type_Const]
	 ,F.id_Form			as [ID_Form_Const]
FROM [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM] ACTF (nolock)
INNER JOIN [dbo].[DIC_Count_Form] F (nolock)
	on F.id = ACTF.ID_FORM
	and F.dell = 0
INNER JOIN [dbo].[DIC_Count_Name] N (nolock)
	on N.id = ACTF.ID_COUNT
	and N.dell = 0
INNER JOIN [dbo].[DIC_Count_Type] T (nolock)
	on T.id = ACTF.ID_TYPE
Where 
	1=1
	and ACTF.dell = 0


go

