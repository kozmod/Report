CREATE PROCEDURE [dbo].[setSite_CostHouse]
	@Site		varchar(10)
	,@Contator 	varchar(100)
		
AS
BEGIN

BEGIN TRANSACTION Site_Up;  

	Insert into dbo.Site (
	[SiteNumber]
	,[TypeHome]
	,[NContract]
	,[DateContract]
	,[SmetCost]
	,[SumCost]
	,[FinishBilding]
	,[Contractor]
	,[CostHouse]
	,[CostSite]
	,[SaleClients]
	,[DebtClients]
	,[StatusPeiment]
	,[StatusJobs]
	,[QueueBilding]
	,[ReductionFactor]
	,[NumberSession]
	)
	Select
		[SiteNumber]
		,[TypeHome]
		,[NContract]
		,[DateContract]
		,[SmetCost]
		,[SumCost]
		,[FinishBilding]
		,[Contractor]
		,E.Price_sum
		,[CostSite]
		,[SaleClients]
		,[DebtClients]
		,[StatusPeiment]
		,[StatusJobs]
		,[QueueBilding]
		,[ReductionFactor]
		,[NumberSession]
	From dbo.Site S
	outer apply(
				Select 
					sum(E.Price_sum) as Price_sum 
				From dbo.Estimate E
				Where 
					S.Contractor = E.Contractor
					and S.SiteNumber = E.SiteNumber
					and S.TypeHome = E.TypeHome
					and E.TableType = 2
					and E.dell = 0
					) E
	Where 
		S.dell = 0
		and S.SiteNumber = @Site
		and S.[Contractor] = @Contator

	
	update S
		set S.dell = 1
	From (
		Select 
			S.*
			,row_number() over (order by S.DateCreate DESC) as R_N 
		 From dbo.Site S
		where 
			dell = 0
			and SiteNumber = @Site
			and [Contractor] = @Contator
		)S
		where 
			S.R_N = 2
	
COMMIT TRANSACTION Site_Up;

end


GO
