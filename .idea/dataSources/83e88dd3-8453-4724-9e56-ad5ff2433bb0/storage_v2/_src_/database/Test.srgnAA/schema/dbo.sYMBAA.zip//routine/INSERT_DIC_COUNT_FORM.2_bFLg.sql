CREATE PROCEDURE [dbo].[INSERT_DIC_COUNT_FORM]   
--declare
	@Name		varchar(100) = null
	,@New_name	varchar(100) = null
AS 
/*  
exec dbo.INSERT_DIC_COUNT_FORM  
@Name= 'ДДД' 
*/ 
BEGIN    

	declare   
		@ID_FORM	int = null   
		,@ID		int = null  
		
	declare    
		@OutputTbl TABLE (ID INT)   
		
	--set @Name= case when @Name= '-1' or @Nameis null then @New_Nameelse @Nameend   
	
	BEGIN TRAN  
	
		--проверяем новое имя   
		--ищем элемент  
		
		SELECT 
			@ID_FORM = ID_FORM
			, @ID = ID 
		FROM [dbo].[DIC_Count_FORM] (NOLOCK) 
		WHERE 
			Name = @Name
			and dell = 0   

			--SELECT @ID, @ID_FORM
	
		--удаляем его  
		
		IF not exists(SELECT 1 FROM [dbo].[DIC_COUNT_FORM] (nolock) WHERE Name = @New_Name and dell = 0) 
			UPDATE [dbo].[DIC_Count_FORM]    
				set dell = 1  
			OUTPUT DELETED.ID into @OutputTbl
			WHERE 
				ID_FORM = @ID_FORM    
		ELSE
			UPDATE [dbo].[DIC_Count_FORM] 
				set  dell = 1 
			WHERE 
				ID_FORM = @ID_FORM  
				
				
		
		
		IF (@Name = '-1' or @Name is null or @ID is null) --новый элемент или не существующий старый
			Begin  
				IF (@ID IS NULL) 
					begin
					rollback;
					return; --если старый не существует, то ошибка
					end
				--вставляем новый
				INSERT INTO  [dbo].[DIC_Count_FORM]([ID_FORM],[NAME])    
				SELECT top 1     
					isnull(max(ID_FORM)+1,-1)     
					,@New_Name   
				FROM  [dbo].[DIC_Count_FORM](nolock)     
				
				
				IF (Select count(1) FROM [dbo].[DIC_Count_FORM] (nolock) ) = 0     
					INSERT INTO  [dbo].[DIC_Count_FORM]([ID_FORM],[Name]) VALUES (1,@New_Name)   
					
			End    
			
		ELSE  
			Begin   
			
			--SELECT @ID_FORM =  isnull(max(ID_FORM),-1) FROM [dbo].[DIC_Count_FORM](nolock)    
			
			--вставляем его в таблицу      
			
				if exists(SELECT  1 FROM [dbo].[DIC_COUNT_FORM] CN (nolock) inner join @OutputTbl T on T.id = CN.id)  
					begin
						--чистим буферную табличку
						delete from @OutputTbl
						 --старое на новое 
						INSERT INTO [dbo].[DIC_Count_FORM]([ID_FORM],[Name])
							OUTPUT INSERTED.id INTO @OutputTbl  
						VALUES (@ID_FORM, @New_name) 
					end
				else    
						INSERT INTO @OutputTbl
						select 
							ID
						FROM [dbo].[DIC_COUNT_FORM] (nolock) 
						WHERE 
							1=1
							and Name = @New_Name
							and dell = 0        
							
							
						
					
					
				IF object_id('tempdb..#FRK_ACCOUNT_COUNT_TYPE_FORM_temp') is not null    
					drop table #FRK_ACCOUNT_COUNT_TYPE_FORM_temp    
					
				CREATE TABLE #FRK_ACCOUNT_COUNT_TYPE_FORM_temp (               
																[ID_IDEAL_CORR]	int
																,ID_FORM	int
																,ID_Count	int
																,ID_TYPE	int               
																)    
																
				--удаляем его из таблицы зависимостей   
				UPDATE [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM]    
					set dell = 1   
				OUTPUT     
					DELETED.[ID_IDEAL_CORR]    
					,DELETED.ID_FORM    
					,DELETED.ID_FORM    
					,DELETED.ID_TYPE   
				into #FRK_ACCOUNT_COUNT_TYPE_FORM_temp   
				WHERE ID_FORM = @ID       
				
				INSERT INTO dbo.FRK_ACCOUNT_COUNT_TYPE_FORM ([ID_IDEAL_CORR], ID_FORM, ID_Count, ID_TYPE)   
				SELECT     
					FRK.[ID_IDEAL_CORR]    
					,O.ID    
					,FRK.ID_FORM    
					,FRK.ID_TYPE   
				FROM #FRK_ACCOUNT_COUNT_TYPE_FORM_temp FRK   
				cross join @OutputTbl O  
			End  
				
	commit tran;  
end
GO

