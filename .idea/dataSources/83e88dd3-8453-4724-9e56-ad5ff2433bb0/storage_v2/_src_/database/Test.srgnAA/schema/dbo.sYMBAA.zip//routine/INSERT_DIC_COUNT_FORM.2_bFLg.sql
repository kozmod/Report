
CREATE PROCEDURE [dbo].[INSERT_DIC_COUNT_FORM] 
	@New_Name	varchar(100) = null
	,@Name		varchar(100) = null
AS
/*
 exec dbo.INSERT_DIC_COUNT_FORM 
	@name = 'ДДД'
*/
BEGIN
	
	declare
		@ID_FORM	int = null
		,@ID		int = null
	declare 
		@OutputTbl TABLE (ID INT)

	set @Name = case when @Name = '-1' or @Name is null then @New_Name end

	BEGIN TRAN
	--ищем элемент
	SELECT @ID_FORM = ID_FORM, @ID = ID FROM [dbo].[DIC_Count_Form] (NOLOCK) WHERE NAME = @NAME

	--удаляем его
	UPDATE [dbo].[DIC_Count_Form]
		set dell = 1
	WHERE ID_FORM = @ID_FORM
	
	IF @ID is null
		Begin

			INSERT INTO  [dbo].[DIC_Count_Form]([id_Form],[Name])
			SELECT top 1
				isnull(max(ID_FORM)+1,1)
				,@New_Name
			FROM  [dbo].[DIC_Count_Form](nolock)
			
			IF (Select count(1) FROM [dbo].[DIC_Count_FORM] (nolock) ) = 0
				INSERT INTO  [dbo].[DIC_Count_FORM]([id_FORM],[Name]) VALUES (1,@New_Name)	
		End
	ELSE
	Begin
		SELECT @ID_FORM =  isnull(max(ID_FORM),-1) FROM [dbo].[DIC_Count_Form](nolock)
		
			--вставляем его в таблицу
		INSERT INTO  [dbo].[DIC_Count_Form]([id_Form],[Name])OUTPUT INSERTED.id INTO @OutputTbl  VALUES (@ID_FORM,@New_Name)  

		IF object_id('tempdb..#FRK_ACCOUNT_COUNT_TYPE_FORM_temp') is not null
			drop table #FRK_ACCOUNT_COUNT_TYPE_FORM_temp
		CREATE TABLE #FRK_ACCOUNT_COUNT_TYPE_FORM_temp (
														ID_ACCOUNT	int
														,ID_COUNT	int
														,ID_FORM	int
														,ID_TYPE	int
														)


		--удаляем его из таблицы зависимостей
		UPDATE dbo.FRK_ACCOUNT_COUNT_TYPE_FORM
			set dell = 1
		OUTPUT 
			DELETED.ID_ACCOUNT
			,DELETED.ID_COUNT
			,DELETED.ID_FORM
			,DELETED.ID_TYPE
		into #FRK_ACCOUNT_COUNT_TYPE_FORM_temp
		WHERE ID_FORM = @ID

		
		INSERT INTO dbo.FRK_ACCOUNT_COUNT_TYPE_FORM (ID_ACCOUNT, ID_COUNT, ID_FORM, ID_TYPE)
		SELECT 
			FRK.ID_ACCOUNT
			,FRK.ID_COUNT
			,O.ID
			,FRK.ID_TYPE
		FROM #FRK_ACCOUNT_COUNT_TYPE_FORM_temp FRK
		cross join @OutputTbl O
	End
	commit tran;

end


GO

