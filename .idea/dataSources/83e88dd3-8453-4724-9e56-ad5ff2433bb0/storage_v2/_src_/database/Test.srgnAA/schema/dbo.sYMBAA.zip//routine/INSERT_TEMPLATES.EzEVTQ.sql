
CREATE PROC [dbo].[INSERT_TEMPLATES]
@Template_Name varchar(100),
@Template_Desc varchar(500) = '',
@Template_Format varchar(20),
@File_Path nvarchar(200)
AS
BEGIN

SET NOCOUNT ON;
 
DECLARE @SQL nvarchar(1000);

SET @SQL = 'INSERT INTO TBL_Documents_Templates(Tanplate_Name,Template_Format, Tanplate_Desc, fileDATA, fileGUID)
                 VALUES ( '+@Template_Name+', '+ @Template_Format+', '+@Template_Desc+'
                 ,(SELECT * FROM OPENROWSET( N''' +@File_Path+ ', SINGLE_BLOB) AS text1)
                 ,NEWID()
				 )'
EXEC (@SQL)
END
GO

