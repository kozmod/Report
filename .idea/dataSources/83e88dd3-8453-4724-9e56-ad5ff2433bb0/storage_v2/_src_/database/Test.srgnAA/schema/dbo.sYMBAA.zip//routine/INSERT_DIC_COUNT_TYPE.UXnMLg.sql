
CREATE PROCEDURE [dbo].[INSERT_DIC_COUNT_TYPE] 
	@Name		varchar(100) = null
	,@New_Name	varchar(100) = null
AS
/*
 exec dbo.INSERT_DIC_COUNT_TYPE 
	@name = 'ДДД'
*/
BEGIN
	
	declare
		@ID_TYPE	int = null
		,@ID		int = null
	declare 
		@OutputTbl TABLE (ID INT)
	
	set @Name = case when @Name = '-1' or @Name is null then @New_Name end

	BEGIN TRAN
	--ищем элемент
	SELECT @ID_TYPE = ID_TYPE, @ID = ID FROM [dbo].[DIC_Count_TYPE] (NOLOCK) WHERE NAME = @NAME

	--удаляем его
	UPDATE [dbo].[DIC_Count_TYPE]
		set dell = 1
	WHERE ID_TYPE = @ID_TYPE
	

	IF @ID is null
		Begin
			INSERT INTO  [dbo].[DIC_Count_TYPE]([id_TYPE],[Name])
			SELECT top 1
				isnull(max(ID_TYPE)+1,-1)
				,@New_Name
			FROM  [dbo].[DIC_Count_TYPE](nolock)
			
			IF (Select count(1) FROM [dbo].[DIC_Count_TYPE] (nolock) ) = 0
				INSERT INTO  [dbo].[DIC_Count_TYPE]([id_TYPE],[Name]) VALUES (1,@New_Name)
		End		
	ELSE
	Begin
		SELECT @ID_TYPE =  isnull(max(ID_TYPE),-1) FROM [dbo].[DIC_Count_TYPE](nolock)
			--вставляем его в таблицу
		INSERT INTO  [dbo].[DIC_Count_TYPE]([id_TYPE],[Name])OUTPUT INSERTED.id INTO @OutputTbl  VALUES (@ID_TYPE,@New_Name)  


		CREATE TABLE #FRK_ACCOUNT_COUNT_TYPE_FORM_temp (
														ID_ACCOUNT	int
														,ID_COUNT	int
														,ID_FORM	int
														,ID_TYPE	int
														)

		--удаляем его из таблицы зависимостей
		UPDATE [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM]
			set dell = 1
		OUTPUT 
			DELETED.ID_ACCOUNT
			,DELETED.ID_COUNT
			,DELETED.ID_FORM
			,DELETED.ID_TYPE
		into #FRK_ACCOUNT_COUNT_TYPE_FORM_temp
		WHERE ID_TYPE = @ID

		
		INSERT INTO [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM] (ID_ACCOUNT, ID_COUNT, ID_FORM, ID_TYPE)
		SELECT 
			FRK.ID_ACCOUNT
			,FRK.ID_COUNT
			,FRK.ID_FORM
			,O.ID
		FROM #FRK_ACCOUNT_COUNT_TYPE_FORM_temp FRK
		cross join @OutputTbl O
	End
	commit tran;

end


GO

