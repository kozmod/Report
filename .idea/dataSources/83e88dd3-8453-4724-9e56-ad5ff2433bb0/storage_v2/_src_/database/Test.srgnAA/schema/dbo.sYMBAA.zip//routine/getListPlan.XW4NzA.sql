
 --SELECT  
 --                    P.* 
 --                    ,(SELECT P.[Quantity] - COUNT(*) FROM [Site] S WHERE S.SiteTypeID = P.TypeID AND S.[dell] = 0) as Rest 
 --                    ,(P.[SmetCost] *P.[Quantity]) as SmetCostSUM 
 --                    ,(P.[SaleCost] *P.[Quantity]) as SaleCostSUM 
                
 --               From dbo.[FinPlan] P 
 --               WHERE [dell] = 0 
  CREATE PROCEDURE [dbo].[getListPlan]      as
 SELECT  
                    -- P.* 
                    -- ,(SELECT P.[Quantity] - COUNT(*) FROM [Site] S WHERE S.SiteTypeID = P.TypeID AND S.[dell] = 0) as Rest 
                    max(P.[Quantity]) - (count(1)*(max(cast(S.dell as smallint))-1)*(-1)) 	as Rest
					,max(TypeName) as TypeName
					
					 ,max(P.[SmetCost] *P.[Quantity])	as SmetCostSUM 
                     ,max(P.[SaleCost] *P.[Quantity])	as SaleCostSUM 
					,max(P.id		)					as [id]
					,max(P.TypeName	  )					as [TypeName]
					,max(P.Quantity	  )					as [Quantity]
					,max(P.SmetCost	  )					as [SmetCost]
					,max(P.SaleCost	  )					as [SaleCost]

					,max(P.NumberSession)				as [NumberSession]
					,max(P.DateCreate )					as [DateCreate]
					,max(P.TypeID		)				as [TypeID]
                From dbo.[FinPlan] P 
				left join dbo.[Site] S
					on S.SiteTypeID = P.TypeID
                WHERE 
					P.[dell] = 0 
					and S.dell = 0
				group by 
					P.TypeID
  		union all
		Select 
			        max(P.[Quantity]) - (count(1)*(max(cast(S.dell as smallint))-1)*(-1)) 	as Rest
					,max(TypeName)
					,max(P.[SmetCost] *P.[Quantity]) as SmetCostSUM 
                    ,max(P.[SaleCost] *P.[Quantity]) as SaleCostSUM 
					,max(P.id		)					as [id]
					,max(P.TypeName	  )					as [TypeName]
					,max(P.Quantity	  )					as [Quantity]
					,max(P.SmetCost	  )					as [SmetCost]
					,max(P.SaleCost	  )					as [SaleCost]
	
					,max(P.NumberSession)				as [NumberSession]
					,max(P.DateCreate )					as [DateCreate]
					,max(P.TypeID		)				as [TypeID]
		From dbo.[FinPlan] P              
		Inner JOIN dbo.[Site] S 
			ON P.[TypeID] = S.[SiteTypeID]
			and P.dell = 0  
		group by 
			P.[TypeID] 
		having 
			sum(cast(S.dell as int)) = count(P.[TypeID] )  
		order by [TypeID]
 GO
