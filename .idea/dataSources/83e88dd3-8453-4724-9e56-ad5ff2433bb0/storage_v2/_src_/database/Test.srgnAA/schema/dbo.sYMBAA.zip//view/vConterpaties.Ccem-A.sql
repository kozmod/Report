
CREATE view [dbo].[vConterpaties]
as
	Select distinct
		max(F.Name)			as FormName
		,max(T.Name)		as TypeName
		,max(N.Name)		as CountName
		,A.Name_Cor	as AccountName
	From [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM] FRK (nolock)
	inner join [dbo].[DIC_Count_Form] F (nolock)
		on FRK.ID_FORM = F.ID
		and F.dell = 0
	inner join [dbo].[DIC_Count_Type] T (nolock)
		on FRK.ID_Type = T.ID
		and T.dell = 0
	inner join [dbo].[DIC_Count_Name] N (nolock)
		on FRK.ID_COUNT = N.ID
		and N.dell = 0
	left join [dbo].[Account] A (nolock)
		on FRK.ID_ACCOUNT = A.id
		and A.dell = 0
	Where
		1=1 
		and FRK.dell = 0
	Group by 
		A.Name_Cor


GO

