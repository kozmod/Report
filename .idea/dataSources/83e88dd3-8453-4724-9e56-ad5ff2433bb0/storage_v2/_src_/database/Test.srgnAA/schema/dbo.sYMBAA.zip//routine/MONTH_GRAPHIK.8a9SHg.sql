
CREATE PROC [dbo].[MONTH_GRAPHIK]
	@DateFrom	datetime2,
	@DateTO		datetime2		
AS
BEGIN
declare
	@Sum_OSR decimal(28,2) = (Select sum(Value) From [dbo].[SiteOSR] S Where Dell = 0) --забивать ее той датой которой оне идутъ
declare
	@Sum_Quantity int = (Select sum(Quantity) From [dbo].[FinPlan] Where Dell = 0)
declare
	@all_Taxes decimal(28,2) = 0
declare
	@monthNumbers int = (select -1*datediff(month,@DateTO,getdate())) 

SELECT @all_Taxes= (sum(F.[SaleCost]*F.[Quantity]) * sum(CP.[sale_Exp]) - @Sum_OSR)/@Sum_Quantity*sum(CP.[INCOMTAX])	
FROM dbo.[FinPlan] F 
cross join [dbo].[TBL_COMMAND_PROPERTY] CP
WHERE F.dell = 0 and  CP.dell = 0

;WITH 
		CTE AS (
				SELECT 1 as id, @DateTO  as [DateTo]
				UNION ALL
				SELECT ID + 1, dateadd(month, 1, [DateTo]) 
				FRom CTE 
				WHERE ID <= datediff(month, @DateTo, @DateFrom)
			)
		,[Count_finish] as (
						Select 
							count(1)	as [count]
							,dateadd(day, 1-day(DATEadd(dd,[FinishBuilding], '19700101')),DATEadd(dd,[FinishBuilding], '19700101'))	as [month]
						From [dbo].[Site]
						where 
							[StatusJobs] = 'Закончен'
							and dell = 0
						group by 
							dateadd(day, 1-day(DATEadd(dd,[FinishBuilding], '19700101')),DATEadd(dd,[FinishBuilding], '19700101'))
						)
		,[count_pay] as (
						select 
							count(1)	as [count] 
							,dateadd(day, 1-day(DATEadd(dd,[FinishBuilding], '19700101')),DATEadd(dd,[FinishBuilding], '19700101'))	as [month]	
						From [dbo].[Site]
						where 
							[StatusPayment] = 'оплачен'
							and dell = 0
						group by 
							dateadd(day, 1-day(DATEadd(dd,[FinishBuilding], '19700101')),DATEadd(dd,[FinishBuilding], '19700101'))
				)
		,[cost]	as (
				Select 
					sum([Price_sum]/S.k) as [Price_sum]
					,max(CTE.[DateTo]) as [DateTo]
				From dbo.Site S
				inner join dbo.KS KS
					on KS.Contractor = S.Contractor
					and KS.SiteNumber = S.SiteNumber
					and KS.dell = 0
				cross join CTE
				where 
					--не удалили
					s.Dell  = 0
					--Смотрим кс дату, главный решил.
					and dateadd(day, 1-day(DATEadd(dd,KS.KS_Date, '19700101')),DATEadd(dd,KS.KS_Date, '19700101')) = CTE.DateTo
					/*
					--домик или сделали или вот точно завтра будет готов, мама клянусь шеф!
					and (/*S.StatusJobs = 'Закончен'
					or */dateadd(day, 1-day(DATEadd(dd,S.[FinishBuilding], '19700101')),DATEadd(dd,S.[FinishBuilding], '19700101')) = CTE.DateTo )
					-- дата начала гдето давно. Либо только сделали
						and DATEadd(dd,S.DateContract, '19700101') <= CTE.DateTo
					*/
				
				group by cte.id
				)
		,[add_exp]	as (
							SELECT 
								sum(S.SaleHouse - (S.SmetCost*S.k) - (isnull(@Sum_OSR,0)/isnull(@Sum_Quantity,1))-@all_Taxes)	as [Add_Cost]
								,max([DateTo]) as DATETO
							  FROM dbo.[Site] S
							  cross join ( SELECT id,[DateTo] FROM  CTE) CTE
							  WHERE  
								dateadd(day, 1-day(DATEadd(dd,S.DateContract, '19700101')),DATEadd(dd,S.DateContract, '19700101')) = CTE.DateTo
								and S.dell = 0
							group by CTE.id
						)
		,saleclients	as (
							SELECT
								sum(Cred)	as S_CRED
							FROM [dbo].[FRK_ACCOUNT_COUNT_TYPE_FORM] FRK (nolock)
							cross join CTE
							INNER JOIN dbo.ACCOUNT A
								ON A.Id = FRK.ID_COUNT
								and A.DELL = 0
							INNER JOIN DIC_COUNT_TYPE T
								ON T.id = FRK.ID_TYPE 
								and T.dell = 0
								and T.id_Type = 4
							WHERE
								dateadd(day, 1-day(DATEadd(dd,A.Date, '19700101')),DATEadd(dd,A.Date, '19700101'))  = CTE.DateTo
								and FRK.dell = 0
								)

		,DCF as (
					Select 
						--денежный поток
							(max(saleclients.S_CRED) - isnull(sum([Price_sum]/S.k),0) - (sum(S.SaleHouse) - (sum(S.SmetCost*S.k)) - (isnull(@Sum_OSR,0)/isnull(@Sum_Quantity,1))-@all_Taxes)-isnull(@Sum_OSR,0) - @all_Taxes*isnull(@Sum_Quantity,0))as [Profit]
							,power((1+max(KDD.[RateOfReturn])/12),@monthNumbers+CTE.id)		as [k]
							,max(CTE.dateto)	as [DateTo]
						From dbo.Site S
						--контрагент будет клиентом Макс этого не сделал, будем молить тёмных богов, чтобы на нас снизошло рождественское чудо и дедушка мороз принёс нам нового Макса с прямыми руками и хорошими сро(а)ками.
						cross join CTE
						cross join saleclients
						cross join [dbo].[KD_Discount] KDD
						left join dbo.KS KS
							on KS.Contractor = S.Contractor
							and KS.SiteNumber = S.SiteNumber
							and KS.dell = 0
						where 
							--не удалили
							s.Dell  = 0	
							and KDD.dell = 0
							--домик или сделали или вот точно завтра будет готов, мама клянусь шеф!
							and (/*S.StatusJobs = 'Закончен'
							or */dateadd(day, 1-day(DATEadd(dd,S.[FinishBuilding], '19700101')),DATEadd(dd,S.[FinishBuilding], '19700101')) = CTE.DateTo )
							-- дата начала гдето давно. Либо только сделали
								and DATEadd(dd,S.DateContract, '19700101') <= CTE.DateTo
						group by CTE.id
					)

Select
		CTE.DateTo							as [month]
		,CF.count							as [count_finish]
		,CP.count							as [count_pay]
		,c.[Price_sum]
		,saleclients.S_CRED
		,saleclients.S_CRED -c.[Price_sum]	as [Oper_profit] 
		,[Add].[Add_Cost]
		,@all_Taxes/12						as [all_Taxes]
		,@Sum_OSR							as [Sum_OSR]
		,DCF.[Profit]*DCF.k					as [DCF]
		,DCF.[Profit]		
from CTE
	full join  [Count_finish] CF
		on CTE.dateto = CF.month
	full join [count_pay] CP
		on CTE.dateto = CP.month
	full join [cost] c
		on CTE.DateTo = c.dateto
	full join [add_exp]	[Add]
		on [Add].DATETO = CTE.DateTo
	full join [DCF] DCF
		on DCF.DATETO = CTE.DateTo
	cross join saleclients

order by CTE.DateTo
SET NOCOUNT OFF;
END


GO

