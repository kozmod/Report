


CREATE PROCEDURE [dbo].[ComputeK] 

	 @SiteNumber	varchar(200) = null-- '1'
	 ,@id_count_const	int = null--'ГРЭМ'
	 ,@K			decimal(34,2) = null--10
as
/*
exec [dbo].[ComputerK]
 @SiteNumber	=  1
 ,@Contractor	= 'ГРЭМ'
 ,@K			= 10


*/
Begin
	
BEGIN TRAN;  
update  [dbo].[Estimate]
	set dell = 1
Where
	[dell] = 0
	and [SiteNumber] = @SiteNumber
	and [id_count_const] = @id_count_const
	and [TableType] = 2


insert into [dbo].[Estimate] (
								[SiteNumber]
								,[TypeHome]
								--,[Contractor]
								,[id_count_const]
								,[JM_name]
								,[JobsOrMaterials]
								,[BindedJob]
								,[Unit]
								,[Value]
								,[Price_one]
								--,[Price_sum]
								,[BuildingPart]
								,[TableType]
								,[dell]
							)
Select distinct
	Res.[SiteNumber]																	
	,Res.[TypeHome]
	,Res.[id_count_const]
		--,Res.[Contractor]
	,Res.[JM_name]
	,Res.[JobsOrMaterials]
	,Res.[BindedJob] 
	,Res.[Unit] 
	,Res.[Value] 
	,Res.[Price_one]*@K
	--,E.[Value]*E.[Price_one]*@K	
	,Res.[BuildingPart] 
	,2
	,0
From (
		Select
			E.*
			,row_number () over(partition by E.[SiteNumber],E.[id_count_const],[TypeHome], [BuildingPart],[JM_name],[BindedJob] order by E.[DateCreate] desc) as RN
						--,row_number () over(partition by E.[SiteNumber],E.[id_count_const],[TypeHome], [BuildingPart],[JM_name],[BindedJob] order by E.[DateCreate] desc) as RN
		From [dbo].[Estimate] E
		Where
			E.[dell] = 0
			and E.[SiteNumber] = @SiteNumber
			--and E.[Contractor] = @Contractor
						and E.[id_count_const] = @id_count_const
			and E.[TableType] = 1
			
		)Res
Where Res.[RN] = 1

COMMIT TRAN; 


End


go

