
CREATE PROCEDURE [dbo].[setSite]
--ключевые параметры
	@SiteNumber			varchar(10)	
	,@TypeHome			varchar(100)
	,@Contractor		varchar(100)
--новые значения
	,@DateContract		int
	,@FinishBilding		int
	,@StatusJobs		varchar(100)
	,@StatusPeiment		varchar(10)
	,@SaleClients		float
	,@DebtClients		float
	,@SmetCost			float
	,@CostHouse			float
	,@SaleHouse			float
	,@CostSite			float
	,@SumCost			float
as
Begin
set @Contractor =  ltrim(rtrim(@Contractor))


BEGIN TRAN T2;  
set @Contractor =  ltrim(rtrim(@Contractor))


update [dbo].[Site]
	set dell = 1
where 
	[SiteNumber]		= @SiteNumber		
	and ltrim(rtrim([Contractor]))	= @Contractor	
	and [TypeHome]					= @TypeHome
	and dell = 0	



insert into [dbo].[Site]		(
								[SiteNumber]		
								,[TypeHome]			
								,[NContract]			
								,[DateContract]		
								,[SmetCost]			
								,[SumCost]			
								,[FinishBilding]		
								,[Contractor]		
								,[CostHouse]			
								,[CostSite]			
								,[SaleClients]		
								,[DebtClients]		
								,[StatusPeiment]		
								,[StatusJobs]		
								,[QueueBilding]		
								,[SaleHouse]							
								,[dell]
								)
				
Select top 1
	@SiteNumber		
	,@TypeHome		
	,[NContract]		
	,@DateContract
	,@SmetCost	
	,@SumCost
	,@FinishBilding	
	,@Contractor	
	,@CostHouse		
	,@CostSite	
	,@SaleClients	
	,@DebtClients	
	,@StatusPeiment
	,@StatusJobs	
	,[QueueBilding]			
	,@SaleHouse						
	,0
From [dbo].[Site]
where 
	[SiteNumber]					= @SiteNumber		
	and ltrim(rtrim([Contractor]))	= @Contractor	
	and [TypeHome]					= @TypeHome
	and dell = 1
order by id desc

COMMIT TRAN T2;  

end
GO
